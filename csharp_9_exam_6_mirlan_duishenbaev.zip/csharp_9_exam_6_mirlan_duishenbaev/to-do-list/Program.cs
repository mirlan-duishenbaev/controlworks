﻿using System;
using System.IO;
using System.Text;

namespace to_do_list
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;

            string currentDir = Directory.GetCurrentDirectory();
            MyHttpServer server = new MyHttpServer(currentDir, 8888);
        }
    }
}
