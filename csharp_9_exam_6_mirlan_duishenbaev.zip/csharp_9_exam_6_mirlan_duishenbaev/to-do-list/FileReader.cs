﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace to_do_list
{
    public class FileReader
    {
        public static List<T> ReadFile<T>(string path)
        {
            try
            {
                string info = System.IO.File.ReadAllText(path);
                return JsonConvert.DeserializeObject<List<T>>(info);
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine($"File do not read {path}.\nError: {e.Message}");
                return new List<T>();
            }
            catch (JsonReaderException e)
            {
                Console.WriteLine($"Error file to path: {path}.\nError: {e.Message}");
                return new List<T>();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Un initilization error{e.Message}");
                return new List<T>();
            }
        }
    }
}
