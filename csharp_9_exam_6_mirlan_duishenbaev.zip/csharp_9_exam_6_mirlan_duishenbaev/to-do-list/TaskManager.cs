﻿using System;
using System.Collections.Generic;
using System.Text;

namespace to_do_list
{
    class TaskManager
    {
        public List<Task> tasks = new List<Task>();

        public void AddTask(Task t)
        {
            tasks.Add(t);
        }

        public void ChangeStatusOrDesc(Task t)
        {

        }

        public void ViewTask(Task t)
        {

        }

        public void MainPage()
        {

        }
    }
}
