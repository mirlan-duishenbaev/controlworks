﻿using System;
using System.Collections.Generic;
using System.Text;

namespace to_do_list
{
    public class Task
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Performer { get; set; }
        public DateTime StartDate { get; set; }
        public string Status { get; set; }
        public string Action { get; set; }
        public string Description { get; set; }

        public Task(int iD, string name, string performer, DateTime startDate, string status, string action)
        {
            ID = iD;
            Name = name;
            Performer = performer;
            StartDate = startDate;
            Status = status;
            Action = action;
        }

        public Task()
        {

        }


    }
}
