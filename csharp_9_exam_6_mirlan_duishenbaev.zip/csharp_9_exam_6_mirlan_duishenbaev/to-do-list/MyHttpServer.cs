﻿using RazorEngine;
using RazorEngine.Templating;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

namespace to_do_list
{
    class MyHttpServer
    {
        private Thread _serverThread;
        private string _siteDirectory;
        private string _filesDirectory;
        private HttpListener _listener;
        private int _port;

        public MyHttpServer(string currentDir, int port)
        {
            this.Initialize(currentDir, port);
        }

        private void Initialize(string currentDir, int port)
        {
            _siteDirectory = currentDir + @"\site";
            _filesDirectory = currentDir + @"\files";
            _port = port;
            _serverThread = new Thread(Listen);
            _serverThread.Start();
            Console.WriteLine($"Сервер запущен на порту: {port}");
            Console.WriteLine($"Файлы сайта лежат в папке: {_siteDirectory}");
            Console.WriteLine($"Файлы с данными лежат в папке: {_filesDirectory}");
        }

        private void Listen()
        {
            _listener = new HttpListener();
            _listener.Prefixes.Add("http://localhost:" + _port.ToString() + "/");
            _listener.Start();
            while (true)
            {
                try
                {
                    HttpListenerContext context = _listener.GetContext();

                    Process(context);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        public string ShowTaskList()
        {
            TaskManager Tm = new TaskManager();

            Tm.tasks = FileReader.ReadFile<Task>("../netcoreapp3.1/files/tasks.json");

            var page = Path.Combine(_siteDirectory, "index.html");

            return BuildHtml(page, Tm.tasks);
        }

        private void Process(HttpListenerContext context)
        {
            string filename = context.Request.Url.AbsolutePath;
            Console.WriteLine(filename);

            filename = filename.Trim('/');

            var absFilename = Path.Combine(_siteDirectory, filename);

            string content;

            switch (filename)
            {
                case "index.html":

                    if (context.Request.HttpMethod == "GET")
                    {
                        content = ShowTaskList();
                    }
                    else if (context.Request.HttpMethod == "POST")
                    {
                        var body = ReadBodyFromPostRequest(context.Request);
                        var parts = body.Split('=');
                        string value1 = parts[parts.Length - 1];

                        string value2 = parts[0].Replace('+', ' ');

                        List<Task> tasks = FileReader.ReadFile<Task>("../netcoreapp3.1/files/tasks.json");

                        if (value1 == "delete")
                        {
                            tasks.Remove(tasks.Find(x => x.ID == Convert.ToInt32(value2)));

                            DataWriter dw = new DataWriter();
                            dw.TaskDataWriter(tasks, "../netcoreapp3.1/files/tasks.json");
                            content = ShowTaskList();
                        }
                        else if(value1 == "perform")
                        {
                            Task t = tasks.Find(x => x.ID == Convert.ToInt32(value2));
                            t.Status = "Done";

                            DataWriter dw = new DataWriter();
                            dw.TaskDataWriter(tasks, "../netcoreapp3.1/files/tasks.json");
                            content = ShowTaskList();
                        }
                        else if (value1 == "Add")
                        {
                            var Arr = body.Split('&', '=');

                            Task t = new Task();
                            t.Name = Arr[1].Replace('+', ' ');
                            t.Performer = Arr[3];
                            t.Description = Arr[5];
                            t.StartDate = DateTime.Now;
                            t.ID = tasks.Count + 1;
                            t.Status = "New";

                            tasks.Add(t);
                            DataWriter dw = new DataWriter();
                            dw.TaskDataWriter(tasks, "../netcoreapp3.1/files/tasks.json");
                            content = ShowTaskList();
                        }
                        else
                        {
                            content = ShowTaskList();
                        }
                    }
                    else
                    {
                        content = BuildHtml(absFilename);
                    }
                    break;
                case "tasks.html":
                    if (context.Request.HttpMethod == "GET")
                    {
                        var body = ReadBodyFromPostRequest(context.Request);
                        var parts = body.Split('=');
                        string value1 = parts[parts.Length - 1];

                        string value2 = parts[0].Replace('+', ' ');

                        context.Response.Redirect("http://localhost:8888/tasks.html");
                        content = BuildHtml(absFilename);
                    }
                    else
                    {
                        content = BuildHtml(absFilename);
                    }                  
                    break;
                default:
                    content = File.ReadAllText(absFilename);
                    break;
            }

            if (File.Exists(absFilename))
            {
                try
                {
                    byte[] htmlBytes = System.Text.Encoding.UTF8.GetBytes(content);

                    Stream fileStream = new MemoryStream(htmlBytes);

                    context.Response.ContentType = GetContentType(absFilename);

                    context.Response.ContentLength64 = fileStream.Length;

                    byte[] buffer = new byte[16 * 1024];

                    int dataLength;
                    do
                    {
                        dataLength = fileStream.Read(buffer, 0, buffer.Length);

                        context.Response.OutputStream.Write(buffer, 0, dataLength);
                    } while (dataLength > 0);

                    fileStream.Close();
                    context.Response.StatusCode = (int)HttpStatusCode.OK;
                    context.Response.OutputStream.Flush();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                }

            }
            else
            {
                context.Response.StatusCode = (int)HttpStatusCode.NotFound;
            }
            context.Response.OutputStream.Close();
        }

        private string ReadBodyFromPostRequest(HttpListenerRequest request)
        {
            string bodyText = string.Empty;
            if (request.HasEntityBody)
            {
                using (Stream body = request.InputStream)
                {
                    using (var reader = new StreamReader(body, request.ContentEncoding))
                    {
                        bodyText = reader.ReadToEnd();
                    }
                }
            }

            return bodyText;
        }

        private string GetContentType(string filename)
        {
            var dictionary = new Dictionary<string, string> {
                {".css",  "text/css"},
                {".html", "text/html"},
                {".ico",  "image/x-icon"},
                {".js",   "application/x-javascript"},
                {".json", "application/json"},
                {".png",  "image/png"}
            };

            string contentType = "";
            string fileExtension = Path.GetExtension(filename);
            dictionary.TryGetValue(fileExtension, out contentType);
            return contentType;
        }

        private string BuildHtml<T>(string filename, T model)
        {
            string html;
            string layoutPath = Path.Combine(_siteDirectory, "layout.html");
            string filePath = Path.Combine(_siteDirectory, filename);

            var razorService = Engine.Razor;

            if (!razorService.IsTemplateCached("layout", null))
                razorService.AddTemplate("layout", File.ReadAllText(layoutPath));

            if (!razorService.IsTemplateCached(filename, typeof(T)))
            {
                razorService.AddTemplate(filename, File.ReadAllText(filePath));
                razorService.Compile(filename, typeof(T));
            }

            html = razorService.Run(filename, typeof(T), model);
            return html;
        }

        private string BuildHtml(string filename)
        {
            return BuildHtml(filename, new object());
        }

        public void Stop()
        {
            _serverThread.Abort();
            _listener.Stop();
        }
    }
}
