﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;

namespace to_do_list
{
    public class DataWriter
    {
        public void TaskDataWriter<Task>(List<Task> tasks, string filePath)
        {
            if (!File.Exists(filePath))
            {
                File.Create(filePath);
            }

            string json = JsonSerializer.Serialize(tasks);
            File.WriteAllText(filePath, json);
        }
    }
}
