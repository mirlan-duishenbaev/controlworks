﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace controlwork
{
    class CatsApp : Cat
    {
        List<Cat> cats = new List<Cat>();

        public string filePath = "../../../catdata.json";

        public void CatsShow()
        {
            DataReader(filePath);
            CatSort();
            Console.WriteLine("--------------- CAT'S LIST ----------------\n" +
                "|     Name    |  Age  |  Saturation  |  Mood  |  Health  |  Life Level  |");
            foreach (var item in cats) Console.WriteLine(item.ToString());
        }

        public void CatAddRequest()
        {
            CatsShow();
            Console.Write("Do you want to add new cat in the list?  ");
            string reply = Console.ReadLine();
            Console.WriteLine();
            switch (reply.ToLower())
            {
                case "y":
                    DataReader(filePath);
                    CatAdd();
                    CatAddRequest();
                    break;
                case "n":
                    break;
                default:
                    Console.WriteLine("Invalid data entered.");
                    break;
            }
        }

        public void CatAdd()
        {
            Console.Write("Enter the name of a new cat: ");
            Name = Console.ReadLine();
            Console.WriteLine();

            try
            {
                Console.Write("Enter the cat's age: ");
                Age = int.Parse(Console.ReadLine());
                Console.WriteLine();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                CatAdd();
            }

            SaturationLvl = 0;
            MoodLvl = 0;
            HealthLvl = 0;

            cats.Add(new Cat(Name, Age, SaturationLvl, MoodLvl, HealthLvl, LifeLvl));

            CatSort();
            DataWriter(cats, filePath);
        }

        public void CatSort()
        {
            CompareLvl<Cat> cL = new CompareLvl<Cat>();
            cats.Sort(cL);
        }

        public void DataWriter(List<Cat> cats, string filePath)
        { 
            if (!File.Exists(filePath))
            {
                File.Create(filePath);
            }

            string json = JsonSerializer.Serialize(cats);
            File.WriteAllText(filePath, json);
        }

        public List<Cat> DataReader(string filePath)
        {
            try
            {
                string json = File.ReadAllText(filePath);
                cats = JsonSerializer.Deserialize<List<Cat>>(json); ;
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return cats;
        }

        public void CatAction()
        {

            Random r = new Random();
            int bad = r.Next(1, 10);
            CatEvents events = new CatEvents();


            DataReader(filePath);
            Console.WriteLine("Please, select the cat.");
            string name = Console.ReadLine();
            Cat cat = cats.Find(x => x.Name == name);

            Console.WriteLine("What do you want to do with cat? (feed, play, treat)");
            string reply = Console.ReadLine();
            switch (reply)
            {
                case "feed":
                    if(bad != 10)
                    {
                        cat.Feed();
                        CatSort();
                        DataWriter(cats, filePath);
                    }
                    else
                    {
                        events.GetIntox += IntoxEvent;
                        events.GetEvent();
                        DataWriter(cats, filePath);
                    }
                    break;

                case "play":
                    cat.Play();
                    CatSort();
                    DataWriter(cats, filePath);
                    break;

                case "treat":
                    cat.Treat();
                    CatSort();
                    DataWriter(cats, filePath);
                    break;

                default:
                    Console.WriteLine("You chose invalid action");
                    break;
            }
        }

        public void IntoxEvent()
        {
            Cat cat = new Cat();

            //cat = cats.Find(x => x.Name == cat.Name);


            if (cat.HealthLvl > 30 && cat.MoodLvl > 30)
            {
                cat.HealthLvl -= 30;
                cat.MoodLvl -= 30;
                Console.WriteLine("{0} is intoxicated!", cat.Name);
            }
            else
            {
                cats.Remove(cat);
                Console.WriteLine("{0} died and was removed from the list!", cat.Name);
            }
        }
    }
}
