﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    class CompareLvl<T> : IComparer<T> where T : Cat
    {
        public int Compare(T x, T y)
        {
            if(x.LifeLvl < y.LifeLvl) return 1;
            if (x.LifeLvl > y.LifeLvl) return -1;
            return 0;
        }
    }
}
