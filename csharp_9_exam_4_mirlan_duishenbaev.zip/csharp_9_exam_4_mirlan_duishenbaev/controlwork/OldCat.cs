﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    class OldCat : IStrategy
    {
        public int LvlUp(int lvl)
        {
            return lvl + 2;
        }

        public int LvlDown(int lvl)
        {
            return lvl - 10;
        }
    }
}
