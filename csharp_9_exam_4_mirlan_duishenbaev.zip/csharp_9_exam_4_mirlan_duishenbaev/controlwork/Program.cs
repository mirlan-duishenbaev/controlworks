﻿using System;

namespace controlwork
{
    class Program
    {
        static void Main(string[] args)
        {
            CatsApp catsApp = new CatsApp();
            //catsApp.CatAddRequest();
            //catsApp.CatsShow();
            //catsApp.CatAction();
            //catsApp.CatsShow();

            catsApp.CatsShow();
            catsApp.CatAction();
            catsApp.CatsShow();
        }
    }
}
