﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    public delegate void EventHandler();

    class CatEvents
    {
        public event EventHandler GetIntox;

        public void GetEvent()
        {
            GetIntox();
        }

        public event EventHandler GetInj;

        //public event EventHandler GetDie;
        //public event EventHandler FullSatur;
        //public event EventHandler FullMood;
        //public event EventHandler FullHealth;

        //public void Intoxication(Cat cat)
        //{
        //    cat.SaturationLvl -= 30;
        //    cat.HealthLvl -= 30;
        //}

        //public void Injury(Cat cat)
        //{
        //    cat.MoodLvl -= 30;
        //    cat.HealthLvl -= 40;
        //}

        //public void CatsDeath(List<Cat> cats, Cat cat)
        //{
        //    if (cat.HealthLvl <= 0)
        //    {
        //        cats.Remove(cat);
        //        Console.WriteLine($"{cat.Name} died and was removed from the list.");
        //    }
        //}



    }
}
