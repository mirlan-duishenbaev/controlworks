﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    class FeedKote /*: IStrategy*/
    {
        public void Action(Cat cat)
        {
            if(cat.Age > 0 && cat.Age < 6)
            {
                cat.SaturationLvl += 10;
                cat.MoodLvl += 10;
                cat.HealthLvl += 10;
            }
            if(cat.Age >= 6 && cat.Age < 11)
            {
                cat.SaturationLvl += 5;
                cat.MoodLvl += 5;
                cat.HealthLvl += 5;
            }
            else
            {
                cat.SaturationLvl += 2;
                cat.MoodLvl += 2;
                cat.HealthLvl += 2;
            }
        }
    }
}
