﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    class YoungCat : IStrategy
    {
        public int LvlUp(int lvl)
        {
            return lvl + 10;
        }

        public int LvlDown(int lvl)
        {
            return lvl - 2;
        }
    }
}
