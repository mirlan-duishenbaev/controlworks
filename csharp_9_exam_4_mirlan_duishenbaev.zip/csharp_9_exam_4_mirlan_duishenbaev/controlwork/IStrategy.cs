﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    interface IStrategy
    {
        int LvlUp(int lvl);
        int LvlDown(int lvl);
    }
}
