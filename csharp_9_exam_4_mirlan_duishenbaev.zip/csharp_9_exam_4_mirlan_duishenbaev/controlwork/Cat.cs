﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace controlwork
{
    class Cat
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public int SaturationLvl { get; set; }
        public int MoodLvl { get; set; }
        public int HealthLvl { get; set; }

        public int LifeLvl
        {
            get
            {
                return (SaturationLvl + MoodLvl + HealthLvl) / 3;
            }

            set
            {
                SaturationLvl = value;
                MoodLvl = value;
                HealthLvl = value;
            }
        }

        public Cat(string name, int age, int saturationLvl, int moodLvl, int healthLvl, int lifeLvl)
        {
            Name = name;
            Age = age;
            SaturationLvl = saturationLvl;
            MoodLvl = moodLvl;
            HealthLvl = healthLvl;
            LifeLvl = lifeLvl;
        }

        public Cat()
        {
        }

        public override string ToString()
        {
            return $"----------------------------------------------------------------------------\n" +
                $"|  {Name,9}  |  {Age,3}  | {SaturationLvl,11}  |  {MoodLvl,4}  |  {HealthLvl,6}  |  {LifeLvl,10}  |\n";
        }

        private IStrategy GetStrategy()
        {
            IStrategy strategy = null;
            if (Age <= 5)
            {
                strategy = new YoungCat();
            }
            if (Age > 5 && Age <= 10)
            {
                strategy = new AdultCat();
            }
            if (Age > 10)
            {
                strategy = new OldCat();
            }
            return strategy;
        }

        public void Feed()
        {
            SaturationLvl = GetStrategy().LvlUp(SaturationLvl);
            MoodLvl = GetStrategy().LvlUp(MoodLvl);
            HealthLvl = GetStrategy().LvlUp(HealthLvl);
        }



        public void Play()
        {
            SaturationLvl = GetStrategy().LvlDown(SaturationLvl);
            MoodLvl = GetStrategy().LvlUp(MoodLvl);
            HealthLvl = GetStrategy().LvlUp(HealthLvl);
        }

        public void Treat()
        {
            MoodLvl = GetStrategy().LvlUp(MoodLvl);
            HealthLvl = GetStrategy().LvlUp(HealthLvl);
        }

        

    }
}
