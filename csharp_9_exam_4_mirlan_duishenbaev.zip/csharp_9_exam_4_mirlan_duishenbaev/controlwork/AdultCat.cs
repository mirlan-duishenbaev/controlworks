﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controlwork
{
    class AdultCat : IStrategy
    {
        public int LvlUp(int lvl)
        {
            return lvl + 5;
        }

        public int LvlDown(int lvl)
        {
            return lvl - 5;
        }
    }
}
